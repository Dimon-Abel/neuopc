using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Opc.ConfigTool")]
[assembly: AssemblyDescription("OPC .NET OPC Server Configuration Tool")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("OPC Foundation")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright © 2003-2022 OPC Foundation")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyFileVersion("2.1.109.0")]
[assembly: AssemblyVersion("2.1.109.0")]


