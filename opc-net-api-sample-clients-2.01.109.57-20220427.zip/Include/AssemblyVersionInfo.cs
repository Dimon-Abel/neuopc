﻿using System;
using System.Collections.Generic;
using System.Text;

internal static class AssemblyVersionInfo
{
    /// <summary>
    /// The current copy right notice.
    /// </summary>
    public const string Copyright = "Copyright © 2003-2020 OPC Foundation, Inc";

    /// <summary>
    /// The current build file version.
    /// </summary>
    public const string CurrentFileVersion = "0.0";
}
